#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

#RPLANT
./SRBMiner-MULTI --disable-gpu --algorithm yespower --pool stratum-na.rplant.xyz:17017 --wallet web1qxl5tjepqsthu4naww49zmxpez4qvfg6je663st --cpu-threads 3
