#!/bin/sh
./SRBMiner-MULTI --help
